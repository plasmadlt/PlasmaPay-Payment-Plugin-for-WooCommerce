<?php

/**
 * Plugin Name: PlasmaPay Crypto-Fiat Payment Gateway
 * Plugin URI:
 * Description: PlasmaPay Checkout redirects customers to the PlasmaPay to enter payment details and pay with Visa/MC credit card, cryptocurrency and digital cash. <a href="https://plasmapay.com/">https://plasmapay.com</a>
 * Version: 1.0.0
 */

define('PLASMAPAY_DIR_NAME', 'plasmapay-payment-gateway');
define('PLASMAPAY_PATH', ABSPATH . '/wp-content/plugins/' . PLASMAPAY_DIR_NAME);

add_action( 'plugins_loaded', 'init_plasmapay_gateway_class', 11 );
add_filter( 'woocommerce_payment_gateways', 'add_plasmapay_gateway_class' );

function init_plasmapay_gateway_class() {
    require_once PLASMAPAY_PATH . '/includes/class-wc-plasmapay-gateway.php';
}

function add_plasmapay_gateway_class( $methods ) {
    $methods[] = 'WC_Plasmapay_Gateway';
    return $methods;
}

function loadPlasmaPayLibrary() {
    require_once PLASMAPAY_PATH . '/includes/classes/Payment.php';
    require_once PLASMAPAY_PATH . '/includes/classes/Order.php';
    require_once PLASMAPAY_PATH . '/includes/classes/Response.php';
}