<?php
namespace Plasmapay;

class Payment {
    protected $api_key;
    protected $cancelUrl;
    protected $notificationUrl;
    protected $order;
    protected $returnUrl;

    const URL_INVOISES = "https://app.plasmapay.com/business/api/v1/public/invoices";

    public function __construct($api_key) {
        $this->api_key = $api_key;
    }

    protected function _apiRequest() {

        $ch = curl_init(self::URL_INVOISES);

        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json', 'Authorization: Bearer ' . $this->api_key));

        if (!empty($this->order)) {
            $order = $this->getOrder();
            $postfields = array (
                "merchantId" => (string)$order->getId(),
                "currencyCode" => $order->getCurrency(),
                "amount" => $order->getTotal(),
                "description" => $order->getDescription(),
                "accountId" => (string)$order->getUserId()
            );
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postfields));
        }
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

        $json = curl_exec($ch);

        $error = curl_error($ch);
        curl_close($ch);

        if ($json === false) {
            throw new \Exception("cURL error " . $error);
        }

        $response = json_decode($json);

        if ($response->code == "400") {
            throw new \Exception($response->message);
        }

        return $response;
    }

    public function submit() {
        try {
            $response = $this->_apiRequest();
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $response = array("errors" => $msg, "message" => $msg);
        }
        return new Response($response);
    }

    public function setCancelUrl($url) {
        $this->cancelUrl = $url;
        return $this;
    }

    public function setNotificationUrl($url) {
        $this->notificationUrl = $url;
        return $this;
    }

    public function setOrder(Order $order) {
        $this->order = $order;
        return $this;
    }

    public function setReturnUrl($url) {
        return $this->returnUrl;
    }

    public function getCancelUrl() {
        return $this->cancelUrl;
    }

    public function getNotificationUrl() {
        return $this->notificationUrl;
    }

    public function getOrder() {
        return $this->order;
    }

    public function getReturnUrl() {
        return $this->returnUrl;
    }
}