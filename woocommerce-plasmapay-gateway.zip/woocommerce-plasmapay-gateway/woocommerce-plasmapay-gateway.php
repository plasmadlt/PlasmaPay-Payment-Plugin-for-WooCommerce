<?php

/**
 * Plugin Name: Woocommerce PlasmaPay Gateway
 * Plugin URI:
 * Description: This plugin add the payment gateway which allow you to charge the сredit сard and payment by wallet to wallet. <a href="https://plasmapay.com/">https://plasmapay.com</a>
 * Version: 1.0.0
 */

define('PLASMAPAY_DIR_NAME', 'woocommerce-plasmapay-gateway');
define('PLASMAPAY_PATH', ABSPATH . '/wp-content/plugins/' . PLASMAPAY_DIR_NAME);

add_action( 'plugins_loaded', 'init_plasmapay_gateway_class', 11 );
add_filter( 'woocommerce_payment_gateways', 'add_plasmapay_gateway_class' );

function init_plasmapay_gateway_class() {
    require_once PLASMAPAY_PATH . '/includes/class-wc-plasmapay-gateway.php';
}

function add_plasmapay_gateway_class( $methods ) {
    $methods[] = 'WC_Plasmapay_Gateway';
    return $methods;
}

function loadPlasmaPayLibrary() {
    require_once PLASMAPAY_PATH . '/includes/classes/Payment.php';
    require_once PLASMAPAY_PATH . '/includes/classes/Order.php';
    require_once PLASMAPAY_PATH . '/includes/classes/Response.php';
}